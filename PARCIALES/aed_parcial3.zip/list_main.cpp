#include "list.hpp"


int main() {
  List<int> l;

  for(int i = 0; i < 5; ++i)
   l.push_back(i);

  for(int i = 0; i < 5; ++i)
    l.push_front(i);

  l.display();

  l.pop_back();
  l.pop_front();

  l.display();
  
  return 0;
}
