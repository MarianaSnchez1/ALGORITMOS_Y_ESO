
template <typename T>
List<T>::List() {
  back = nullptr;
  front = nullptr;
  size = 0;
}

template <typename T>
List<T>::~List() {
  while(!empty()){
    pop_back();
  }
}

template <typename T>
bool List<T>::empty() {
  return size == 0;
}

/****Implemente estos métodos****/
template <typename T>
void List<T>::push_back(T v) {
 
}

template <typename T>
void List<T>::pop_back() {
  
}
/*******************************/

template <typename T>
T List<T>::get_back() {
  return back->val;
}

/****Implemente estos métodos****/
template <typename T>
void List<T>::push_front(T v) {
  
}

template <typename T>
void List<T>::pop_front() {
  
}
/********************************/

template <typename T>
T List<T>::get_front() {
  return front->val;
}

template <typename T>
void List<T>::display() {
  Cell<T> *tmp = back;
  while(tmp != nullptr){
    std::cout << tmp->val << " ";
    tmp = tmp->next;
  }
  std::cout << "\n";
}
