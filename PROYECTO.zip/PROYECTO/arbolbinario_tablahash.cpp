//Arbol binario con tabla hash .cpp
#include "arbolbinario_tablahash.hpp"

/*______________________________________ ARBOL BINARIO ______________________________________*/

/*_______________________PRIVATE_______________________*/
Node * BT::min (Node *root) const{
  if (root==nullptr){
    return nullptr;
  } else{
    if (root->left == nullptr){
      return root;
    } else{
      return min (root->left);
    }
  }
}

Node * BT::max (Node *root) const{
  if (root==nullptr){
    return nullptr;
  } else{
    if (root->right == nullptr){
      return root;
    } else{
      return max(root->right);
    }
  }
}

void BT::remove (Node *&root, string variable){
  if (root == nullptr){
    return;
  }
  if (variable < root->variable){
    remove (root->left, variable);
  }
  else if (variable > root->variable){
    remove (root->right, variable);
  }
  else if(root->left == nullptr){
    Node *tmp = root;
    root = root->right;
    delete tmp;
    count --;
  }
  else if (root->left != nullptr && root->right != nullptr){
    root->variable = min(root->right)->variable;
    remove(root->right, root->variable);
  }
}

void BT::clear (Node * & root){
  if (root != nullptr){
    clear (root->left);
    clear (root->right);
    delete root;
  }
  root = nullptr;
  count = 0;
}

void BT::display(Node *root) const{
  if (root != nullptr){
    display(root->left);
    cout << root->variable << endl;
    display(root->right);
  }
}

void BT::insert (Node *&t, string variable){
  if (t == nullptr){
    t = new Node;
    t->variable = variable;
    t->left = t->right = nullptr;
  } else if (t->left == nullptr && t->right == nullptr){
      if ((rand() % 2) == 0) insert(t->left, variable);
      else insert(t->right, variable);
  } else if (t->left == nullptr){
    insert(t->left, variable);
  } else {
    insert(t->right, variable);
  }
}

Node *BT::find(Node *t, string variable) const{
  if (t == nullptr) return nullptr;
  if (variable == t->variable) return t;
  if (variable < t->variable){
    return find (t->left, variable);
  } else{
    return find(t->right, variable);
  }
}

/*_______________________PUBLIC_______________________*/
BT::BT(){
  tree = nullptr;
  count = 0;
}

BT::~BT(){
  clear();
}

void BT::remove (string variable){
  remove(tree,variable);
}

bool BT::empty() const{
  return (count==0);
}

void BT::clear(){
  clear(tree);
}

bool BT::find(string variable) const{
  return (find(tree, variable)!=nullptr);
}

void BT::insert(string variable){
  insert(tree,variable);
}

void BT::display() const{
  display(tree);
}
