//Arbol binario con tabla hash .hpp

#ifndef _arbolbinario_tablahash_hpp_
#define _arbolbinario_tablahash_hpp_
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

/*_________________________________________ ARBOL BINARIO ________________________________________*/
struct Node{
  string variable;
  Node *left, *right;
};
class BT{
private:
  int count;
  Node *tree;

  Node *min (Node *root) const;
  Node *max (Node *root) const;

  void remove(Node *&root, string variable);
  void clear(Node *&root);
  void display(Node *root) const;
  void insert(Node *&t, string variable);
  Node *find (Node *t, string variable) const;


public:
  BT();
  ~BT();
  Node * Root() {return tree;}
  void remove(string variable);
  bool empty() const;
  void clear();
  bool find(string variable) const;
  void insert(string variable);
  void display() const;
};

#endif
