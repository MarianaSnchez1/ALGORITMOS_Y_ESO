//Montecarlo.cpp
#include "Montecarlo.hpp"
#include <cstdlib>
#include <time.h>


void MCTS (BT tree, map<string,int> &var_amb){
  vector<vector<string>> final_des;

  for (int i=0; i<100; i++){ // Se simula 100 veces con situaciones diferentes
    Node *root = tree.Root();
    vector<string> variables; //Para ir guardando las variables ambientales por las que pasa
    int count = 0; //Se genera uhn contador para ver si se alcanza a conservar el ambiente o si se extingue

    variables.push_back(root->variable);
    count += var_amb[root->variable];

    while(root->left != nullptr || root->right != nullptr){ //Va recorriendo los nodos principales, los ingresa a las variables
      Node *select_node = selection(root);
      variables.push_back(select_node->variable);
      count += var_amb[select_node->variable];
      root = select_node;
    }

    while (count < 20 && count > -20) { //Simula nuevas situaciones hasta que se conserve/extigna el ecosistema
      simulation(root, var_amb);
      Node * new_node = selection(root);
      variables.push_back(new_node->variable);
      count += var_amb[new_node->variable];
    }
    backpropagation(variables, count, var_amb);
    if (count >=20) final_des.push_back(variables);
  }
  analisis (final_des, var_amb);
}



Node * selection (Node * &tree){
  if (tree->left != nullptr && tree->right != nullptr){
    //srand(time(NULL));
    //int rdm = 1 + rand() % (2 - 1);
    int rdm = rand() % 2;
    if (rdm == 0) return tree -> left;
    else return tree -> right;
  }
  return expand(tree);
}

Node * expand(Node * &tree){
  if (tree -> left == nullptr){
    return tree -> right;
  } else if (tree -> right == nullptr) {
    return tree -> left;
  }
  return tree;
}


void simulation (Node * &newtree, map<string,int> &var_amb){
  Node* child1 = new Node;
  Node* child2 = new Node;
  //srand(time(NULL));
  //int rango = 1 + rand() % (5 - 1);
  int rango = rand() % 5 + 1;
  //cout << "supuesto alazar " << rango << endl;
  //cout << "puntaje padre " << var_amb[newtree->variable] << endl;
  child1 -> variable = "Sit." + to_string(var_amb.size());
  var_amb[child1->variable] = var_amb[newtree->variable] + rango;

  child2 -> variable = "Sit." + to_string(var_amb.size());
  var_amb[child2->variable] = var_amb[newtree->variable] - rango;

  child1->left = child1->right = child2->left = child2->right = nullptr;
  newtree->left = child1;
  newtree->right = child2;
}


void backpropagation (vector<string> final, int &count, map<string,int> &var_amb) {
  if (20 <= count) cout << "El ecosistema se pudo conservar con un puntaje de: ";
  else cout << "El ecosistema se ha extinguido con un puntaje de: ";
  cout << count << endl;

  cout << "La situaciones que ocurrieron en el momento fueron las siguientes (en el mismo orden de ocurrencia): " << endl;
  for (unsigned i=0; i<final.size()-1; i++) cout << final[i] << ", ";
  cout << final[final.size()-1] << endl;

  cout << "Los valores de esas variables fueron: " << endl;
  for (unsigned i=0; i<final.size()-1; i++) cout << final[i] << " = " << var_amb[final[i]] << endl;;
  cout << "\n \n";
}

void analisis (vector<vector<string>> best_choice, map<string,int> &var_amb){
  cout << "Las veces que se pudo conservar fueron " << best_choice.size() << " veces" << endl;
  cout << "la mejor opcion fue: " << endl;
  vector<string> final = best_choice[0];
  for (unsigned i=1; i<best_choice.size(); i++) if (final.size() >= best_choice[i].size()) final = best_choice[i];
  for (unsigned i=0; i<final.size(); i++) cout << final[i] << " = " << var_amb[final[i]] << endl;
}
