//Puntaje variables ambientales
#include <iostream>
#include <map>
#include <string>
using namespace std;

map<string,int> V_A (){
  //Variables ambientales
  map<string,int> var_amb;
  var_amb["DFH"] = 0; //Destruccion y fragmentacion del habitat
  var_amb["DEOE"] = -1; //Desplazamiento de especies a otros ecosistemas
  var_amb["PPE"] = 1; //Politicas de proteccion del ecosistema

  var_amb["IE"] = 0; //Introducción de especies
  var_amb["PEIR"] = -2; //Proteccion a especies invasoras y reubicacion
  var_amb["EZ"] = 2; //Epizootia

  var_amb["S"] = 0; //Sobreexplotacion
  var_amb["IERPEAP"] = 3; //Implementacion de energias renovables y prohibiciones a la explotacion de areas protegidas
  var_amb["DIE"] = -3; //Daño irreparable al ecosistema

  var_amb["EGD"] = 0; //Efectos geneticos y demograficos
  var_amb["NP"] = -4; //Nuevo patogeno
  var_amb["ECE"] = -5; //Exticion de ciertas especies
  var_amb["IEPTMP"] = 4; //Identificación de la especie en peligro y toma de medidas de protección

  var_amb["VP"] = 0; //Vacunacion de la poblacion
  var_amb["HV"] = 5; //Se hace la vacunacion
  var_amb["NHV"] = -5; //No se hace la vacunación

  var_amb["TPR"] = -6; //Tamaño poblacional reducido
  var_amb["TPNR"] = 6; //Tamaño poblacional no reducido
  //Te amo julian
  /*
  var_amb["EXT"] = -7; //Extincion
  var_amb["C"] = 7; //Se logra la conservacion
  */
  return var_amb;
}
