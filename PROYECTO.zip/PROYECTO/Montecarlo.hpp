//Montecarlo.hpp
#ifndef _montecarlo_hpp_
#define _montecarlo_hpp_
#include "arbolbinario_tablahash.hpp"
#include <string>
#include <map>
#include <vector>
using namespace std;


void MCTS (BT tree, map<string,int> &var_amb);

Node * selection (Node * &tree);

Node * expand(Node * &tree);

void simulation (Node * &newtree, map<string,int> &var_amb);

void backpropagation (vector<string> final, int &count, map<string,int> &var_amb);

void analisis (vector<vector<string>> best_choice, map<string,int> &var_amb);

#endif
